								
								// Interogarile celor 4 cerinte MongoDB si SQL 

/*1. Afisati toate programarile ce au avut loc intre orele 10:00 si 13:30 pe data de 22.03.2024
 (selectand numele pacientilor, medicul la care au programare, ora si tipul de programare.)
*/

db.medici_programari.aggregate([
   {$unwind:"$programari" }, 
   {$match:{"programari.data_programare": ISODate("2024-03-22"),
           "programari.ora_programare": { $gte: "10:00", $lte: "13:30" }}},
   {$lookup: 
       {from: "pacienti_istoricMed_consultatii",
        localField: "programari.id_pacient",
        foreignField: "_id",
        as: "pacient_info" } },
   {$unwind: "$pacient_info"},
   {$project:{ _id: 0,
        nume_pacient:{ $concat: ["$pacient_info.nume", " ", "$pacient_info.prenume"] },
        nume_medic:{ $concat: ["$nume", " ", "$prenume"] },
        ora_programare: "$programari.ora_programare",
        tip_tratament: "$programari.tip_tratament"
   }}  
])


//2. Care sunt facturile ce nu au fost incasate integral si ce suma mai trebuie de incasat? 
//Sol.1
db.facturi_plati.aggregate([
   {$addFields: { suma_incasata: { $sum: "$plati.suma" }}},    //se calculeaza suma totala a platilor pentru fiecare factura. 
   {$match: {
        $expr: 
           { $ne: ["$total_factura", "$suma_incasata"]} }},
    //filtrez documentele din colectie, utlizand si o expresie pentru a compara cele doua campuri punand conditia ca ele sa nu fie egale intre ele
   {$addFields: { suma_ramasa_de_incasat: 
                    { $subtract: ["$total_factura", "$suma_incasata"]}}},
   {$project: { _id: 1, total_factura : 1,
       suma_ramasa_de_incasat: 1}}      
    //noul camp "suma_ramasa_de_incasat" este calculat prin scaderea celor doua campuri : total_factura si suma_incasata       
]);

//Sol.2
db.facturi_plati.aggregate([
   {$project: { _id: 1,
         total_factura: 1,
         suma_incasata: { $sum: "$plati.suma" }, //calculez suma totala a platilor
         suma_ramasa_de_incasat: {
            $subtract: ["$total_factura", { $sum: "$plati.suma" }] 
         }}},
   {$match: { suma_ramasa_de_incasat: { $ne: 0 } }}  
   //suma ramasa de incasat este diferita de 0. Aceasta înseamna ca se afiseaza doar facturile pentru care nu s-a platit integral.
]);


/*3. Care sunt pacientii carora li s-au emis facturi in aceeasi zi in care a fost emisa factura nr.103 ? */
//Sol1.
db.facturi_plati.aggregate([
   {$match: {_id: 103}},
   {$lookup: {
       from: "facturi_plati",
       let: {factura_emitere: "$data_emitere" },
       pipeline:[{$match: {
                    $expr: { $eq: ["$$factura_emitere", "$data_emitere"]},
                       _id: { $ne: 103 } }}],
          as: "facturi_emitere_aceeasi_zi"
      }},
   {$unwind: "$facturi_emitere_aceeasi_zi"},
   {$lookup: {
         from: "pacienti_istoricMed_consultatii",
         localField: "facturi_emitere_aceeasi_zi.id_pacient",
         foreignField: "_id",
         as: "pacienti_facturati"}},
   {$unwind: "$pacienti_facturati"},
   {$project: { _id: 0,
        nume_pacient: {$concat: 
            ["$pacienti_facturati.nume", " ", "$pacienti_facturati.prenume"]}
        }}
]);

//Sol2 
var factura_103 = db.facturi_plati.findOne({ _id: 103 });
db.facturi_plati.aggregate([
   {$match: { data_emitere: factura_103.data_emitere,
              _id: { $ne: 103 } }}, //exclud factura 103 din rezultate
   {$lookup: {
      from: "pacienti_istoricMed_consultatii",
      localField: "id_pacient",
      foreignField: "_id",
      as: "pacient"}},
   {$unwind: "$pacient"},
   {$project: { _id: "$pacient._id",
       nume_pacient: {$concat: ["$pacient.nume", " ", "$pacient.prenume"]}}}
]);

//4. Care este pretul mediu al tratamentelor efectuate de un medic in functie de specializare ?
db.medici_programari.aggregate([
  {$unwind: "$programari" }, 
  {$lookup: { 
      from: "tratamente", 
      localField: "specializare", 
      foreignField: "specializare", 
      as: "tratamente" }},
  {$unwind: "$tratamente" }, 
  {$group: { 
      _id: {nume_medic:
                { $concat: ["$nume", " ", "$prenume"] },
            specializare: "$specializare"}, 
          pret_mediu_tratament: { $avg: "$tratamente.cost" }}}
]);
//Am grupat la final documentele in functie de nume, prenume si specializare. 
//Apoi am calculat pretul mediu al tratamentelor pentru fiecare grup, luand in considerare campul "cost" din documentele din colectia "tratamente".


												//Interogari scrise  in SQL
/*1. Afisati toate programarile ce au avut loc intre orele 10:00 si 13:30 pe data de 22.03.2024
 (selectand numele pacientilor, medicul la care au programare, ora si tipul de programare.)
*/

/*
SELECT 
    CONCAT(nume, ' ', prenume) AS nume_pacient,
	CONCAT(nume_medic, ' ', prenume_medic) AS nume_medic,
    ora_programare, tip_tratament
FROM programari 
INNER JOIN pacienti ON programari.id_pacient = pacienti.id_pacient
INNER JOIN medici ON programari.id_medic = medici.id_medic
WHERE DATE(programari.data_programare) = '2024-03-22'
    AND CAST(ora_programare AS TIME) BETWEEN '10:00:00' AND '13:30:00';

*/

//2. Care sunt facturile ce nu au fost incasate integral si ce suma mai trebuie de incasat? 
/*
SELECT id_factura, 
       total_factura - COALESCE((SELECT SUM(suma) FROM plati
                                WHERE plati.id_factura = facturi.id_factura), 0) AS rest_de_incasat
FROM facturi
WHERE total_factura - COALESCE(
        (SELECT SUM(suma)
        FROM plati
        WHERE plati.id_factura = facturi.id_factura), 0) > 0;

*/

//--3. Care sunt pacientii carora li s-au emis facturi in aceeasi zi  in care a fost intocmita/emisa factura nr.103 ? 

//--Solutia 1 
/*
SELECT CONCAT(nume, ' ', prenume) AS nume_pacient
FROM pacienti 
INNER JOIN facturi ON pacienti.id_pacient = facturi.id_pacient
WHERE data_emitere IN (SELECT data_emitere 
					  FROM facturi
					  WHERE id_factura = 103
) AND pacienti.id_pacient != (
    SELECT id_pacient
    FROM facturi
    WHERE id_factura = 103
)
*/
			  
//--Sol2. cu 2 niveluri de subconsultare [subconsultari in clauza WHERE operatorul IN]
/*
SELECT id_pacient, CONCAT(nume, ' ', prenume) AS nume_pacient
FROM pacienti
WHERE id_pacient IN (
    SELECT id_pacient
    FROM facturi
    WHERE data_emitere IN (
        SELECT data_emitere
        FROM facturi
        WHERE id_factura = 103
    )
) AND id_pacient != (
    SELECT id_pacient
    FROM facturi
    WHERE id_factura = 103
)
*/

//--4. Care este pretul mediu al tratamentelor efectuate de un medic in functie de specializare ?

/*
SELECT m.nume_medic, m.prenume_medic, m.specializare,
	ROUND(AVG(t.cost),1) AS pret_mediu_tratament
FROM medici m
INNER JOIN tratamente t ON m.specializare = t.specializare
GROUP BY m.nume_medic, m.prenume_medic, m.specializare
*/
