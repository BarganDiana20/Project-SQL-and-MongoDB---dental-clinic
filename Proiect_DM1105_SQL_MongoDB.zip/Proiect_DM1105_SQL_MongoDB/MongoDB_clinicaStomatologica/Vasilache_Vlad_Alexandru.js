//1. Extrageți ora programata la Consultatie pentru un anumit pacient, pe baza CNP-ului: 6090712228173.
var pacient = db.pacienti_istoricMed_consultatii.findOne({ CNP: '6090712228173' });
db.medici_programari.aggregate([
  {$match: {"programari.id_pacient": pacient._id,"programari.tip_tratament": "Consultatie"}},
  {$unwind: "$programari"},
  {$match: {"programari.id_pacient": pacient._id,"programari.tip_tratament": "Consultatie"}},
  {$replaceRoot: { newRoot: "$programari" }},
  {$project: {"_id": 0,"ora_programare": 1}}
]);

//2.Extrageti toate programările pentru pacientul cu CNP-ul 2704091234568.
var pacient=db.pacienti_istoricMed_consultatii.findOne({CNP:'2704091234568'});
db.medici_programari.aggregate([
  {$match:{"programari.id_pacient":pacient._id}},
  {$unwind:"$programari"},
  {$match:{"programari.id_pacient":pacient._id}},
  {$replaceRoot:{newRoot:"$programari"}}
]);


//3. Afișează lista cu programarile între orele 11:00 si 12:30 pentru toate zilele.
db.medici_programari.aggregate([
  {$unwind:"$programari"},
  {$match:{"programari.ora_programare":{$gte:"11:00",$lte:"12:30"}}},
  {$lookup:{
    from:"pacienti_istoricMed_consultatii",
    localField:"programari.id_pacient",
    foreignField:"_id",
    as:"detalii_pacient"
  }},
  {$unwind:"$detalii_pacient"},
  {$project:{
    _id:0,
    nume_pacient:{$concat:["$detalii_pacient.nume"," ","$detalii_pacient.prenume"]},
    nume_medic:{$concat:["$nume"," ","$prenume"]},
    data_programare:"$programari.data_programare",
    ora_programare:"$programari.ora_programare",
    tip_tratament:"$programari.tip_tratament"
  }},
  {$sort:{data_programare:1}}
]);


//4.Care sunt zilele in care s-au intocmit (emis) cel puțin 3 facturi ?
db.facturi_plati.aggregate([
  {$group:{
    _id:{$dateToString:{format:"%Y-%m-%d",date:"$data_emitere"}},
    total_facturi:{$sum:1}
  }},
  {$match:{total_facturi:{$gte:3}}},
  {$project:{_id:0,ziua:"$_id",total_facturi:1}}
]);


/*SQL
1. Extrageți ora programata la Consultatie pentru un anumit pacient, pe baza CNP-ului: 6090712228173.

SELECT p.ora_programare
FROM programari p
JOIN pacienti pac ON p.id_pacient = pac.id_pacient
WHERE pac.CNP = '6090712228173' AND p.tip_tratament = 'Consultatie';

2. Extrageti toate programările pentru pacientul cu CNP-ul 2704091234568.

SELECT id_programare, data_programare, ora_programare, tip_tratament
FROM programari p
WHERE id_pacient = (SELECT id_pacient 
					FROM pacienti
					WHERE CNP = '2704091234568'

3. Afișează lista cu programarile între orele 11:00 si 12:30 pentru toate zilele.					

SELECT CONCAT(pac.nume, ' ', pac.prenume) AS nume_pacient,
       CONCAT(med.nume_medic, ' ', med.prenume_medic) AS nume_medic,
       p.data_programare,
       p.ora_programare,
       p.tip_tratament
FROM programari p
INNER JOIN pacienti pac ON p.id_pacient = pac.id_pacient
INNER JOIN medici med ON p.id_medic = med.id_medic
WHERE p.ora_programare BETWEEN '11:00' AND '12:30';					
					
4. Care sunt zilele in care s-au intocmit (emis) cel puțin 3 facturi ?	
				
SELECT data_emitere, COUNT(*) AS numar_facturi
FROM facturi
GROUP BY data_emitere
HAVING COUNT(*) >= 3;		
			
*/




